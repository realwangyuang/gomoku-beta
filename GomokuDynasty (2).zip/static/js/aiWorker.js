// AI Worker for parallel processing

// Transposition table for caching
const transpositionTable = new Map();

// Pattern scores for Gomoku-specific shapes
const patternScores = {
    openFour: 10000,
    openThree: 1000,
    closedFour: 100,
    closedThree: 10,
    twoNonConnectedThrees: 500
};

// Simple opening book
const openingBook = [
    {x: 9, y: 9}, // Center
    {x: 8, y: 8}, // Near center
    {x: 10, y: 10}, // Near center
    {x: 8, y: 10}, // Near center
    {x: 10, y: 8} // Near center
];

// Evaluation function
function evaluateBoard(board) {
    // Same implementation as in ai.js
}

function evaluateDirection(board, x, y, dx, dy) {
    // Same implementation as in ai.js
}

function calculatePatternScore(pattern, openEnds, isWhite) {
    // Same implementation as in ai.js
}

function minimax(board, depth, alpha, beta, isMaximizing) {
    // Same implementation as in ai.js
}

function findBestMove(board) {
    console.log("Worker: findBestMove called with board state:", JSON.stringify(board));
    
    // Check opening book for the first few moves
    const emptyCount = board.flat().filter(cell => cell === null).length;
    if (emptyCount > board.length * board.length - 5) {
        const openingMove = openingBook[board.length * board.length - emptyCount];
        if (openingMove && board[openingMove.y][openingMove.x] === null) {
            console.log("Worker: Using opening book move:", openingMove);
            return openingMove;
        }
    }
    
    const MAX_DEPTH = 3;
    const TIME_LIMIT = 2400; // Slightly less than in ai.js to ensure timely response
    let bestMove;
    let startTime = Date.now();

    function iterativeDeepeningSearch() {
        let depth = 1;
        while (Date.now() - startTime < TIME_LIMIT && depth <= MAX_DEPTH) {
            console.log(`Worker: Searching at depth: ${depth}`);
            let move = minimaxRoot(board, depth, true);
            if (move) {
                bestMove = move;
                console.log(`Worker: Best move found at depth ${depth}: (${move.x}, ${move.y})`);
            }
            depth++;
        }
    }

    try {
        iterativeDeepeningSearch();
        console.log(`Worker: Returning best move: ${JSON.stringify(bestMove)}`);
        
        if (!bestMove || bestMove.x === -1 || bestMove.y === -1) {
            console.log("Worker: No valid move found. Choosing random empty cell.");
            bestMove = getRandomEmptyCell(board);
        }
        
        return bestMove;
    } catch (error) {
        console.error("Worker: Error in findBestMove:", error);
        return getRandomEmptyCell(board);
    }
}

// Add other necessary functions like getBoardHash, orderMoves, getValidMoves, etc.
// (Copy these functions from ai.js)

// Listen for messages from the main thread
self.onmessage = function(e) {
    console.log("Worker: Received message from main thread");
    const board = e.data.board;
    const bestMove = findBestMove(board);
    console.log("Worker: Sending best move to main thread:", bestMove);
    self.postMessage(bestMove);
};

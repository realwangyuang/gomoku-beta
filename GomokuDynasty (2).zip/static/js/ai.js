// Transposition table for caching
const transpositionTable = new Map();

// Pattern scores for Gomoku-specific shapes
const patternScores = {
    openFour: 10000,
    openThree: 1000,
    closedFour: 100,
    closedThree: 10,
    twoNonConnectedThrees: 500
};

// Simple opening book
const openingBook = [
    {x: 9, y: 9}, // Center
    {x: 8, y: 8}, // Near center
    {x: 10, y: 10}, // Near center
    {x: 8, y: 10}, // Near center
    {x: 10, y: 8} // Near center
];

// Evaluation function
function evaluateBoard(board) {
    let score = 0;
    const directions = [[1, 0], [0, 1], [1, 1], [1, -1]];
    const centerX = Math.floor(board.length / 2);
    const centerY = Math.floor(board.length / 2);

    for (let y = 0; y < board.length; y++) {
        for (let x = 0; x < board[y].length; x++) {
            if (board[y][x] !== null) {
                for (const [dx, dy] of directions) {
                    score += evaluateDirection(board, x, y, dx, dy);
                }
                // Add heuristic to prioritize center and near-center moves
                const distanceFromCenter = Math.abs(x - centerX) + Math.abs(y - centerY);
                score += (board[y][x] === 'white' ? 1 : -1) * (10 - distanceFromCenter);
            }
        }
    }

    return score;
}

function evaluateDirection(board, x, y, dx, dy) {
    const player = board[y][x];
    let pattern = '';
    let count = 0;
    let openEnds = 0;

    // Check forward
    let nx = x;
    let ny = y;
    while (nx >= 0 && nx < board.length && ny >= 0 && ny < board.length && count < 6) {
        if (board[ny][nx] === player) {
            pattern += '1';
            count++;
        } else if (board[ny][nx] === null) {
            pattern += '0';
            openEnds++;
            break;
        } else {
            break;
        }
        nx += dx;
        ny += dy;
    }

    // Check backward
    nx = x - dx;
    ny = y - dy;
    while (nx >= 0 && nx < board.length && ny >= 0 && ny < board.length && count < 6) {
        if (board[ny][nx] === player) {
            pattern = '1' + pattern;
            count++;
        } else if (board[ny][nx] === null) {
            pattern = '0' + pattern;
            openEnds++;
            break;
        } else {
            break;
        }
        nx -= dx;
        ny -= dy;
    }

    return calculatePatternScore(pattern, openEnds, player === 'white');
}

function calculatePatternScore(pattern, openEnds, isWhite) {
    const multiplier = isWhite ? 1 : -1;
    
    if (pattern.includes('11111')) return multiplier * 1000000; // Win
    if (pattern === '011110') return multiplier * patternScores.openFour;
    if (pattern === '01110') return multiplier * patternScores.openThree;
    if (pattern.includes('11110') || pattern.includes('01111')) return multiplier * patternScores.closedFour;
    if (pattern.includes('1110') || pattern.includes('0111')) return multiplier * patternScores.closedThree;
    
    // Two non-connected threes
    if ((pattern.match(/1110/g) || []).length + (pattern.match(/0111/g) || []).length >= 2) {
        return multiplier * patternScores.twoNonConnectedThrees;
    }

    return multiplier * (pattern.match(/1/g) || []).length * 10 * (openEnds + 1);
}

function minimax(board, depth, alpha, beta, isMaximizing) {
    const boardHash = getBoardHash(board);
    if (transpositionTable.has(boardHash)) {
        return transpositionTable.get(boardHash);
    }

    if (depth === 0 || isGameOver(board)) {
        const score = evaluateBoard(board);
        transpositionTable.set(boardHash, score);
        return score;
    }

    const moves = orderMoves(board, getValidMoves(board));
    if (isMaximizing) {
        let maxScore = -Infinity;
        for (const move of moves) {
            board[move.y][move.x] = 'white';
            const score = minimax(board, depth - 1, alpha, beta, false);
            board[move.y][move.x] = null;
            maxScore = Math.max(maxScore, score);
            alpha = Math.max(alpha, score);
            if (beta <= alpha) break; // Alpha-beta pruning
        }
        transpositionTable.set(boardHash, maxScore);
        return maxScore;
    } else {
        let minScore = Infinity;
        for (const move of moves) {
            board[move.y][move.x] = 'black';
            const score = minimax(board, depth - 1, alpha, beta, true);
            board[move.y][move.x] = null;
            minScore = Math.min(minScore, score);
            beta = Math.min(beta, score);
            if (beta <= alpha) break; // Alpha-beta pruning
        }
        transpositionTable.set(boardHash, minScore);
        return minScore;
    }
}

function findBestMove(board) {
    console.log("findBestMove called with board state:", JSON.stringify(board));
    
    // Check opening book for the first few moves
    const emptyCount = board.flat().filter(cell => cell === null).length;
    if (emptyCount > board.length * board.length - 5) {
        const openingMove = openingBook[board.length * board.length - emptyCount];
        if (openingMove && board[openingMove.y][openingMove.x] === null) {
            console.log("Using opening book move:", openingMove);
            return openingMove;
        }
    }
    
    const MAX_DEPTH = 3;
    const TIME_LIMIT = 2500; // 2.5 seconds in milliseconds
    let bestMove;
    let startTime = Date.now();

    function iterativeDeepeningSearch() {
        let depth = 1;
        while (Date.now() - startTime < TIME_LIMIT && depth <= MAX_DEPTH) {
            console.log(`Searching at depth: ${depth}`);
            let move = minimaxRoot(board, depth, true);
            if (move) {
                bestMove = move;
                console.log(`Best move found at depth ${depth}: (${move.x}, ${move.y})`);
            }
            depth++;
        }
    }

    try {
        iterativeDeepeningSearch();
        console.log(`Returning best move: ${JSON.stringify(bestMove)}`);
        
        if (!bestMove || bestMove.x === -1 || bestMove.y === -1) {
            console.log("No valid move found. Choosing random empty cell.");
            bestMove = getRandomEmptyCell(board);
        }
        
        return bestMove;
    } catch (error) {
        console.error("Error in findBestMove:", error);
        return getRandomEmptyCell(board);
    }
}

function getBoardHash(board) {
    return board.map(row => row.map(cell => cell === null ? '0' : cell === 'white' ? '1' : '2').join('')).join('');
}

function orderMoves(board, moves) {
    const centerX = Math.floor(board.length / 2);
    const centerY = Math.floor(board.length / 2);
    return moves.sort((a, b) => {
        const distanceA = Math.abs(a.x - centerX) + Math.abs(a.y - centerY);
        const distanceB = Math.abs(b.x - centerX) + Math.abs(b.y - centerY);
        return distanceA - distanceB;
    });
}

function getValidMoves(board) {
    const moves = [];
    const centerX = Math.floor(board.length / 2);
    const centerY = Math.floor(board.length / 2);
    const maxDistance = Math.max(centerX, centerY);

    for (let distance = 0; distance <= maxDistance; distance++) {
        for (let y = Math.max(0, centerY - distance); y <= Math.min(board.length - 1, centerY + distance); y++) {
            for (let x = Math.max(0, centerX - distance); x <= Math.min(board.length - 1, centerX + distance); x++) {
                if (board[y][x] === null && hasAdjacentStone(board, x, y)) {
                    moves.push({x, y});
                }
            }
        }
        if (moves.length > 0) break;
    }

    return moves;
}

function hasAdjacentStone(board, x, y) {
    const directions = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]];
    for (const [dx, dy] of directions) {
        const nx = x + dx;
        const ny = y + dy;
        if (nx >= 0 && nx < board.length && ny >= 0 && ny < board.length && board[ny][nx] !== null) {
            return true;
        }
    }
    return false;
}

function isGameOver(board) {
    return checkWinner(board) !== null || board.every(row => row.every(cell => cell !== null));
}

function checkWinner(board) {
    const directions = [[1, 0], [0, 1], [1, 1], [1, -1]];
    for (let y = 0; y < board.length; y++) {
        for (let x = 0; x < board[y].length; x++) {
            if (board[y][x] !== null) {
                for (const [dx, dy] of directions) {
                    if (countConsecutive(board, x, y, dx, dy) >= 5) {
                        return board[y][x];
                    }
                }
            }
        }
    }
    return null;
}

function countConsecutive(board, x, y, dx, dy) {
    const player = board[y][x];
    let count = 1;
    let nx = x + dx;
    let ny = y + dy;

    while (nx >= 0 && nx < board.length && ny >= 0 && ny < board.length && board[ny][nx] === player) {
        count++;
        nx += dx;
        ny += dy;
    }
    nx = x - dx;
    ny = y - dy;
    while (nx >= 0 && nx < board.length && ny >= 0 && ny < board.length && board[ny][nx] === player) {
        count++;
        nx -= dx;
        ny -= dy;
    }
    return count;
}

function getRandomEmptyCell(board) {
    const emptyCells = [];
    for (let y = 0; y < board.length; y++) {
        for (let x = 0; x < board[y].length; x++) {
            if (board[y][x] === null) {
                emptyCells.push({x, y});
            }
        }
    }
    if (emptyCells.length === 0) {
        console.error("No empty cells found on the board");
        return {x: -1, y: -1};
    }
    return emptyCells[Math.floor(Math.random() * emptyCells.length)];
}

function minimaxRoot(board, depth, isMaximizing) {
    let bestScore = isMaximizing ? -Infinity : Infinity;
    let bestMove;

    const moves = orderMoves(board, getValidMoves(board));
    for (const move of moves) {
        board[move.y][move.x] = isMaximizing ? 'white' : 'black';
        let score = minimax(board, depth - 1, -Infinity, Infinity, !isMaximizing);
        board[move.y][move.x] = null;

        if (isMaximizing ? score > bestScore : score < bestScore) {
            bestScore = score;
            bestMove = move;
        }
    }

    return bestMove;
}

// Simple testing function
function testAIMove(boardState) {
    console.log("Testing AI move with board state:", JSON.stringify(boardState));
    const move = findBestMove(boardState);
    console.log("AI's calculated move:", move);
    return move;
}

// Make the testing function globally accessible
window.testAIMove = testAIMove;

// Make the findBestMove function globally accessible
window.findBestMove = findBestMove;

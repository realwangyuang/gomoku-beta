const canvas = document.getElementById('gameBoard');
const ctx = canvas.getContext('2d');
let boardSize = 19;
let cellSize = 30;
let boardPadding = 15;

let gameBoard = [];
let currentPlayer = 'black';
let gameMode = 'local';
let gameOver = false;
let isAITurn = false;
let room = null;
let playerColor = null;

const newGameBtn = document.getElementById('newGameBtn');
const gameStatus = document.getElementById('gameStatus');
const createRoomBtn = document.getElementById('createRoomBtn');
const joinRoomBtn = document.getElementById('joinRoomBtn');
const roomInput = document.getElementById('roomInput');
const lobby = document.getElementById('lobby');
const gameContainer = document.getElementById('gameContainer');
const gameModeSelect = document.getElementById('gameModeSelect');

const currentPlayerIndicator = document.createElement('div');
currentPlayerIndicator.id = 'currentPlayerIndicator';
gameContainer.insertBefore(currentPlayerIndicator, gameContainer.firstChild);

const socket = io();

function initializeBoard() {
    gameBoard = Array(boardSize).fill().map(() => Array(boardSize).fill(null));
    currentPlayer = 'black';
    gameOver = false;
    isAITurn = false;
    drawBoard();
    updateGameStatus();
    updateCurrentPlayerIndicator();
}

function drawBoard() {
    canvas.width = boardSize * cellSize + 2 * boardPadding;
    canvas.height = boardSize * cellSize + 2 * boardPadding;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#E8C28F';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = '#8B4513';
    ctx.lineWidth = 1;

    for (let i = 0; i < boardSize; i++) {
        const position = i * cellSize + boardPadding;
        ctx.beginPath();
        ctx.moveTo(boardPadding, position);
        ctx.lineTo(canvas.width - boardPadding, position);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(position, boardPadding);
        ctx.lineTo(position, canvas.height - boardPadding);
        ctx.stroke();
    }

    for (let y = 0; y < boardSize; y++) {
        for (let x = 0; x < boardSize; x++) {
            if (gameBoard[y][x]) {
                drawStone(x, y, gameBoard[y][x]);
            }
        }
    }
}

function drawStone(x, y, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(
        x * cellSize + boardPadding,
        y * cellSize + boardPadding,
        cellSize / 2 - 2,
        0,
        2 * Math.PI
    );
    ctx.fill();
    ctx.strokeStyle = color === 'black' ? '#000' : '#999';
    ctx.lineWidth = 1;
    ctx.stroke();
}

function handleClick(event) {
    if (gameOver || (gameMode === 'online' && currentPlayer !== playerColor) || (gameMode === 'ai' && currentPlayer !== 'black')) {
        return;
    }

    const rect = canvas.getBoundingClientRect();
    const x = Math.round((event.clientX - rect.left - boardPadding) / cellSize);
    const y = Math.round((event.clientY - rect.top - boardPadding) / cellSize);

    if (x >= 0 && x < boardSize && y >= 0 && y < boardSize && !gameBoard[y][x]) {
        if (gameMode === 'online') {
            socket.emit('move', { room: room, x: x, y: y, player: playerColor });
        } else {
            makeMove(x, y);
            if (gameMode === 'ai' && !gameOver) {
                isAITurn = true;
                updateGameStatus();
                setTimeout(() => {
                    const aiMove = findBestMove(gameBoard);
                    if (aiMove.x >= 0 && aiMove.y >= 0 && aiMove.x < boardSize && aiMove.y < boardSize && !gameBoard[aiMove.y][aiMove.x]) {
                        setTimeout(() => {
                            makeMove(aiMove.x, aiMove.y);
                            isAITurn = false;
                            updateGameStatus("AI has made its move");
                        }, 500);
                    } else {
                        const randomMove = getRandomValidMove();
                        setTimeout(() => {
                            makeMove(randomMove.x, randomMove.y);
                            isAITurn = false;
                            updateGameStatus("AI made a random move due to an error");
                        }, 500);
                    }
                }, 100);
            }
        }
    }
}

function makeMove(x, y) {
    gameBoard[y][x] = currentPlayer;
    drawBoard();

    if (checkWin(x, y)) {
        gameOver = true;
        updateGameStatus(`${currentPlayer.charAt(0).toUpperCase() + currentPlayer.slice(1)} wins!`);
    } else if (checkDraw()) {
        gameOver = true;
        updateGameStatus("It's a draw!");
    } else {
        currentPlayer = currentPlayer === 'black' ? 'white' : 'black';
        updateGameStatus();
        updateCurrentPlayerIndicator();
    }
}

function checkWin(x, y) {
    const directions = [
        [1, 0], [0, 1], [1, 1], [1, -1]
    ];

    for (const [dx, dy] of directions) {
        let count = 1;
        count += countStones(x, y, dx, dy);
        count += countStones(x, y, -dx, -dy);

        if (count >= 5) {
            return true;
        }
    }

    return false;
}

function countStones(x, y, dx, dy) {
    let count = 0;
    x += dx;
    y += dy;

    while (x >= 0 && x < boardSize && y >= 0 && y < boardSize && gameBoard[y][x] === currentPlayer) {
        count++;
        x += dx;
        y += dy;
    }

    return count;
}

function checkDraw() {
    return gameBoard.every(row => row.every(cell => cell !== null));
}

function updateGameStatus(message) {
    if (message) {
        gameStatus.textContent = message;
    } else if (gameMode === 'online') {
        gameStatus.textContent = `Current player: ${currentPlayer.charAt(0).toUpperCase() + currentPlayer.slice(1)}`;
    } else if (gameMode === 'ai') {
        if (isAITurn) {
            gameStatus.textContent = "AI is thinking...";
        } else {
            gameStatus.textContent = "Your turn (Black)";
        }
    } else {
        gameStatus.textContent = `Your turn (${currentPlayer.charAt(0).toUpperCase() + currentPlayer.slice(1)})`;
    }
}

function updateCurrentPlayerIndicator() {
    currentPlayerIndicator.textContent = `Current Player: ${currentPlayer.charAt(0).toUpperCase() + currentPlayer.slice(1)}`;
    currentPlayerIndicator.style.color = currentPlayer;
}

function switchGameMode() {
    gameMode = gameModeSelect.value;
    initializeBoard();
    updateUI();
}

function updateUI() {
    if (gameMode === 'online') {
        lobby.style.display = 'block';
        gameContainer.style.display = 'none';
    } else {
        lobby.style.display = 'none';
        gameContainer.style.display = 'block';
    }
}

function getRandomValidMove() {
    const emptyCells = [];
    for (let y = 0; y < boardSize; y++) {
        for (let x = 0; x < boardSize; x++) {
            if (gameBoard[y][x] === null) {
                emptyCells.push({x, y});
            }
        }
    }
    return emptyCells[Math.floor(Math.random() * emptyCells.length)];
}

function findBestMove(board) {
    return getRandomValidMove();
}

createRoomBtn.addEventListener('click', () => {
    const roomName = roomInput.value.trim();
    if (roomName) {
        socket.emit('create', { room: roomName });
    }
});

joinRoomBtn.addEventListener('click', () => {
    const roomName = roomInput.value.trim();
    if (roomName) {
        socket.emit('join', { room: roomName });
    }
});

socket.on('join_room_response', (data) => {
    room = data.room;
    playerColor = data.player;
    lobby.style.display = 'none';
    gameContainer.style.display = 'block';
    gameMode = 'online';
    initializeBoard();
    updateGameStatus(`Waiting for opponent... You are ${playerColor}`);
    alert(`You have been assigned the color: ${playerColor}`);
});

socket.on('start_game', (data) => {
    currentPlayer = data.current_player;
    updateGameStatus(`Game started! ${currentPlayer.charAt(0).toUpperCase() + currentPlayer.slice(1)}'s turn`);
    updateCurrentPlayerIndicator();
});

socket.on('update_board', (data) => {
    gameBoard[data.y][data.x] = data.player;
    currentPlayer = data.next_player;
    drawBoard();
    updateGameStatus();
    updateCurrentPlayerIndicator();
});

socket.on('game_over', (data) => {
    gameOver = true;
    updateGameStatus(`Game Over! ${data.winner.charAt(0).toUpperCase() + data.winner.slice(1)} wins!`);
});

socket.on('player_disconnected', () => {
    gameOver = true;
    updateGameStatus("Your opponent has disconnected. Game Over!");
});

socket.on('error', (data) => {
    alert(data.message);
});

canvas.addEventListener('click', handleClick);
newGameBtn.addEventListener('click', initializeBoard);
gameModeSelect.addEventListener('change', switchGameMode);

// Load settings
function loadSettings() {
    const savedBoardSize = localStorage.getItem('boardSize');
    if (savedBoardSize) {
        boardSize = parseInt(savedBoardSize);
        cellSize = Math.floor(570 / boardSize);
        boardPadding = Math.floor((570 - boardSize * cellSize) / 2);
    }

    const savedBoardTheme = localStorage.getItem('boardTheme');
    if (savedBoardTheme) {
        document.body.className = savedBoardTheme;
    }

    const savedSoundVolume = localStorage.getItem('soundVolume');
    if (savedSoundVolume) {
        // Apply sound volume
    }

    const savedSoundToggle = localStorage.getItem('soundToggle');
    if (savedSoundToggle) {
        // Apply sound toggle
    }
}

loadSettings();
initializeBoard();
updateUI();

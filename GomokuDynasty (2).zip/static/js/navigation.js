document.addEventListener('DOMContentLoaded', (event) => {
    const playGameBtn = document.getElementById('playGameBtn');
    const howToPlayBtn = document.getElementById('howToPlayBtn');
    const settingsBtn = document.getElementById('settingsBtn');
    const profileBtn = document.getElementById('profileBtn');
    const leaderboardBtn = document.getElementById('leaderboardBtn');

    if (playGameBtn) playGameBtn.addEventListener('click', () => window.location.href = '/game');
    if (howToPlayBtn) howToPlayBtn.addEventListener('click', () => window.location.href = '/how_to_play');
    if (settingsBtn) settingsBtn.addEventListener('click', () => window.location.href = '/settings');
    if (profileBtn) profileBtn.addEventListener('click', () => window.location.href = '/profile');
    if (leaderboardBtn) leaderboardBtn.addEventListener('click', () => window.location.href = '/leaderboard');
});

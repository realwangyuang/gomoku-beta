from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit, join_room, leave_room
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)

rooms = {}

@app.route("/")
def main_menu():
    return render_template("main.html")

@app.route("/game")
def game():
    return render_template("index.html")

@app.route("/how_to_play")
def how_to_play():
    return render_template("how_to_play.html")

@app.route("/settings")
def settings():
    return render_template("settings.html")

@app.route("/profile")
def profile():
    return render_template("profile.html")

@app.route("/leaderboard")
def leaderboard():
    return render_template("leaderboard.html")

@socketio.on('create')
def on_create(data):
    room = data['room']
    if room not in rooms:
        join_room(room)
        rooms[room] = {'players': 1, 'board': [[None for _ in range(19)] for _ in range(19)], 'current_player': 'black'}
        emit('join_room_response', {'room': room, 'player': 'black'}, room=room)
    else:
        emit('error', {'message': 'Room already exists'})

@socketio.on('join')
def on_join(data):
    room = data['room']
    if room in rooms:
        if rooms[room]['players'] < 2:
            join_room(room)
            rooms[room]['players'] += 1
            player_color = 'white' if rooms[room]['players'] == 2 else 'black'
            emit('join_room_response', {'room': room, 'player': player_color}, room=room)
            if rooms[room]['players'] == 2:
                emit('start_game', {'current_player': rooms[room]['current_player']}, room=room)
        else:
            emit('error', {'message': 'Room is full'})
    else:
        emit('error', {'message': 'Room does not exist'})

@socketio.on('move')
def on_move(data):
    room = data['room']
    x = data['x']
    y = data['y']
    player = data['player']
    if room in rooms:
        if rooms[room]['current_player'] == player and rooms[room]['board'][y][x] is None:
            rooms[room]['board'][y][x] = player
            rooms[room]['current_player'] = 'white' if player == 'black' else 'black'
            emit('update_board', {'x': x, 'y': y, 'player': player, 'next_player': rooms[room]['current_player']}, room=room)
            
            # Check for win condition
            if check_win(rooms[room]['board'], x, y, player):
                emit('game_over', {'winner': player}, room=room)
                del rooms[room]
        else:
            emit('error', {'message': 'Invalid move'}, room=request.sid)

def check_win(board, x, y, player):
    directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
    for dx, dy in directions:
        count = 1
        for i in range(1, 5):
            nx, ny = x + i*dx, y + i*dy
            if 0 <= nx < 19 and 0 <= ny < 19 and board[ny][nx] == player:
                count += 1
            else:
                break
        for i in range(1, 5):
            nx, ny = x - i*dx, y - i*dy
            if 0 <= nx < 19 and 0 <= ny < 19 and board[ny][nx] == player:
                count += 1
            else:
                break
        if count >= 5:
            return True
    return False

@socketio.on('disconnect')
def on_disconnect():
    for room, data in rooms.items():
        if request.sid in socketio.server.rooms[room]:
            leave_room(room)
            data['players'] -= 1
            if data['players'] == 0:
                del rooms[room]
            else:
                emit('player_disconnected', room=room)
            break

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000)
